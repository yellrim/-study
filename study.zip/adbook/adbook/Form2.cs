﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace adbook
{
    public partial class Form2 : Form
    {


        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            string seevar = yerim();
            //Console.WriteLine(seevar);

            //minggu();
            //Bitmap bmpSrc = new Bitmap(@"C:\Users\igh05\OneDrive\Desktop\adbook\adbook\adbook\nyang.jpg", true);
            //ConsoleWriteImage(bmpSrc);
        }
        
        public string yerim()
        {
            Console.WriteLine("-----------------------");
            Console.WriteLine("0. 정보 입력");
            Console.WriteLine("1. 정보 검색");
            Console.WriteLine("2. 정보 수정");
            Console.WriteLine("3. 정보 삭제");
            Console.WriteLine("4. 전체 출력");
            Console.WriteLine("5. 프로그램 종료");
            Console.WriteLine("-----------------------");
            return "메뉴를 선택하세요";
        }

        public void minggu()
        {
            string 본트리업최고 = ConfigurationSettings.AppSettings["CmdMenu"];
            //string 본트리업최고 = (string)ar.GetValue("CmdMenu", typeof(string));
            string[] 마이즈도최고ㅋㅋ = 본트리업최고.Split('^');

            Console.WriteLine("-----------------------");
            for (int i = 0; i < 마이즈도최고ㅋㅋ.Length; i++)
            {
                Console.WriteLine((i+".").ToString() + 마이즈도최고ㅋㅋ[i]);
            }
            Console.WriteLine("-----------------------");
            Console.WriteLine("메뉴를 선택하세요");

            try { 
                int Command = int.Parse(Console.ReadLine());
                Console.WriteLine(마이즈도최고ㅋㅋ[Command]+"메뉴를 실행할것처럼 합니다");
                //minggu();
                return;
            }
            catch(Exception 모두화이팅)
            {
                Console.WriteLine("제시된숫자만 입력해주세용");
                minggu();
                return;
            }
        }
        #region ㅁㄴㅇㄹ
        static int[] cColors = { 0x000000, 0x000080, 0x008000, 0x008080, 0x800000, 0x800080, 0x808000, 0xC0C0C0, 0x808080, 0x0000FF, 0x00FF00, 0x00FFFF, 0xFF0000, 0xFF00FF, 0xFFFF00, 0xFFFFFF };

        public static void ConsoleWritePixel(Color cValue)
        {
            Color[] cTable = cColors.Select(x => Color.FromArgb(x)).ToArray();
            char[] rList = new char[] { (char)9617, (char)9618, (char)9619, (char)9608 }; // 1/4, 2/4, 3/4, 4/4
            int[] bestHit = new int[] { 0, 0, 4, int.MaxValue }; //ForeColor, BackColor, Symbol, Score

            for (int rChar = rList.Length; rChar > 0; rChar--)
            {
                for (int cFore = 0; cFore < cTable.Length; cFore++)
                {
                    for (int cBack = 0; cBack < cTable.Length; cBack++)
                    {
                        int R = (cTable[cFore].R * rChar + cTable[cBack].R * (rList.Length - rChar)) / rList.Length;
                        int G = (cTable[cFore].G * rChar + cTable[cBack].G * (rList.Length - rChar)) / rList.Length;
                        int B = (cTable[cFore].B * rChar + cTable[cBack].B * (rList.Length - rChar)) / rList.Length;
                        int iScore = (cValue.R - R) * (cValue.R - R) + (cValue.G - G) * (cValue.G - G) + (cValue.B - B) * (cValue.B - B);
                        if (!(rChar > 1 && rChar < 4 && iScore > 50000)) // rule out too weird combinations
                        {
                            if (iScore < bestHit[3])
                            {
                                bestHit[3] = iScore; //Score
                                bestHit[0] = cFore;  //ForeColor
                                bestHit[1] = cBack;  //BackColor
                                bestHit[2] = rChar;  //Symbol
                            }
                        }
                    }
                }
            }
            Console.ForegroundColor = (ConsoleColor)bestHit[0];
            Console.BackgroundColor = (ConsoleColor)bestHit[1];
            Console.Write(rList[bestHit[2] - 1]);
        }


        public static void ConsoleWriteImage(Bitmap source)
        {
            int sMax = 39;
            decimal percent = Math.Min(decimal.Divide(sMax, source.Width), decimal.Divide(sMax, source.Height));
            Size dSize = new Size((int)(source.Width * percent), (int)(source.Height * percent));
            Bitmap bmpMax = new Bitmap(source, dSize.Width * 2, dSize.Height);
            for (int i = 0; i < dSize.Height; i++)
            {
                for (int j = 0; j < dSize.Width; j++)
                {
                    ConsoleWritePixel(bmpMax.GetPixel(j * 2, i));
                    ConsoleWritePixel(bmpMax.GetPixel(j * 2 + 1, i));
                }
                System.Console.WriteLine();
            }
            Console.ResetColor();
        }
        #endregion
    }
}
